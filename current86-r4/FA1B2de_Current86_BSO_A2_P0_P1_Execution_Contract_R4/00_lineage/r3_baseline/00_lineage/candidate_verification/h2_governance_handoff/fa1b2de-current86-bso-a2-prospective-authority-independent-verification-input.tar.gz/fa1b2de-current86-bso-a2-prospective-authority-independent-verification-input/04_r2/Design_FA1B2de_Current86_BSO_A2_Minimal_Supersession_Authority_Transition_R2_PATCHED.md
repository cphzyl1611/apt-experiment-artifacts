# FA-1B2de / Track B-SO
## Minimal Current86 B-SO-A2 Supersession & Authority-Transition Design — R2 Patched

**Status:** `PROPOSED_NOT_FROZEN`  
**Mode:** `DESIGN_ONLY`  
**Execution:** `NOT_PERFORMED`  
**Authority materialization:** `NOT_PERFORMED`  
**Old authority supersession:** `NOT_ACTIVE`

---

# 1. Purpose and patch scope

This R2 design is the narrow, design-only successor to:

```text
Design_FA1B2de_Current86_BSO_A2_Minimal_Supersession_Authority_Transition.md
SHA256=6dd52ae5a93e1497f960cce4915d7e132cbd4232756d1758c13e6bc4e606159d
```

It preserves that design's Human-Light Current86 transition architecture and closes exactly the
four blockers returned by the authenticated independent transition review:

```text
B1_INDEPENDENT_VERIFIER_ISOLATION
B2_HUMAN_ORIGIN_PROVENANCE
B3_PROPOSAL_EVIDENCE_ADMISSIBILITY
B4_OWNER_ESCALATION_TERMINAL_SCHEMA
```

Where this document tightens or replaces a baseline rule, this R2 text controls. All baseline
non-regression constraints remain binding. This document does not execute B-SO-A2, perform H1 or
H2, create an authority candidate, activate supersession, publish bindings, run a replay or
experiment, or modify evidence, TSVs, accepted bindings, scoring authority, binding authority,
the 1796 denominator, or the paper.

---

# 2. Authenticated lineage and exact scope typing

The R2 design pins the authenticated frozen V4 lineage as typed references:

```text
supersedes_workflow_architecture_authority_hash=442b5aecd651b320b94eb47b190bf239ba0157634e0a635042ca4d252c65dc40
supersedes_current86_scope_id=34551e904bafa71fb2fb6db33162e94ad41a08eca6c747d429c83760e09c1306
supersedes_freeze_precondition_verification_id=80653cc96d1e3612d5809bd6a6a091f79fe5cd1081c769ec51366b99646faac1
supersedes_final_freeze_handoff_sha256=0af337acc731595167d75f922dd39bbbb48dd1b1b9d3b31723d01408501040de
```

These typed identities replace the baseline's untyped `SUPERSEDES_AUTHORITY_HASH` placeholder.
The old authority remains byte-for-byte historical and continues to control the exact Current86
critical path unless and until a future, independently verified authority is explicitly activated
by H2.

Current86 MUST be bound through exact membership arrays and identity under
`supersedes_current86_scope_id`. Count equality alone is never authority. The following counts are
diagnostics only:

```text
CURRENT86_RAW_COUNT=86
STRUCTURALLY_ELIGIBLE_CANDIDATE_RELATIONS=4219
AUTHENTICATED_HARD_NEGATIVES=58
FORMER_CANDIDATE_LEVEL_HUMAN_EQ_RELATIONS=4161
```

Any membership, identity, or lineage mismatch is fail-closed.

---

# 3. Preserved Human-Light critical path

Only after future H1 acceptance, authority materialization, independent authority verification,
and H2 activation may the exact Current86 path become:

```text
B-SO-R
→ B-SO-A2-PREP
→ isolated PRIMARY_PROPOSER derivation
→ isolated INDEPENDENT_VERIFIER derivation
→ commitment comparison and hard-gate eligibility
→ HUMAN RAW-LEVEL DECISION
→ A2_OWNER_ADJUDICATION_FROZEN or A2_ESCALATION_FROZEN
→ B-SO-V
→ B-SO-P (owner closures only)
```

This R2 design does not authorize any step in that future path.

---

# 4. Complete-candidate invariant and machine boundary

For every raw:

```text
MACHINE_PROPOSAL=NON_AUTHORITATIVE_MACHINE_PROPOSAL
PROPOSAL_INPUT_CANDIDATE_SET=FROZEN_COMPLETE_CANDIDATE_SET_FOR_RAW
PROPOSAL_INPUT_CANDIDATE_SET == FROZEN_COMPLETE_CANDIDATE_SET_FOR_RAW
HIDDEN_PRUNING=PROHIBITED
TOP_K_CANDIDATE_TRUNCATION=PROHIBITED
SILENT_CANDIDATE_SUPPRESSION=PROHIBITED
PROPOSAL_SCORE_AS_NORMATIVE_SIGNAL=PROHIBITED
PROPOSAL_RANK_AS_BINDING_SIGNAL=PROHIBITED
EMBEDDING_OR_POPULARITY_AS_OWNER_AUTHORITY=PROHIBITED
```

The complete candidate universe and relation set must be frozen, hash-bound, auditable,
reconstructable, and expandable in the human interface. No internal heuristic may change
eligibility, scoring authority, binding authority, ranking semantics, pruning semantics, or proof
consumed by B-SO-V/B-SO-P.

---

# 5. B1 — independent verifier isolation

```text
PRIMARY_AND_VERIFIER_CONTEXT_ISOLATION=REQUIRED
```

## 5.1 Common frozen inputs

Primary and verifier MUST consume the same frozen and authenticated proposal-input bundle and the
same exact complete candidate universe. Before either derivation begins, the common bundle MUST
bind at least:

```text
authority_scope_id
raw_key
raw_source_bundle_hash
complete_candidate_universe_hash
complete_candidate_relation_set_hash
candidate_source_bundle_hashes
proposal_evidence_profile_hash
source_class_fact_type_registry_id
historical_output_denylist_hash
input_bundle_hash
```

The common input freeze precedes both derivations. Neither derivation may mutate it.

## 5.2 Exact isolation and freeze order

The required order is:

```text
freeze common input bundle
→ isolated primary derivation
→ freeze primary derivation commitment
→ isolated verifier derivation without primary selected-owner/rationale/intermediates
→ freeze verifier derivation commitment
→ compare commitments
```

Primary and verifier MUST have distinct context identities and distinct run identities. The
verifier, before its own commitment freezes, MUST NOT access:

```text
primary selected owner
primary rationale
primary candidate rank
primary pruning state
primary hidden intermediate score
primary mutable derivation object
```

Shared ranking state, shared candidate-pruning state, shared mutable derivation objects, or use of
the primary proposal as verifier reasoning input are prohibited. Availability of the primary
commitment hash before verifier commitment does not authorize disclosure of its committed fields.

An auditable isolation/order record MUST bind the common `input_bundle_hash`,
`primary_context_identity`, `primary_run_identity`, `primary_commitment_hash`,
`verifier_context_identity`, `verifier_run_identity`, `verifier_commitment_hash`, and ordered freeze
events. The two context identities and the two run identities MUST each be unequal. This record
contains execution metadata only and no chain-of-thought.

## 5.3 Auditable non-CoT commitments

Each derivation commitment exposes exactly the following auditable result fields, plus its schema
identifier:

```text
input_bundle_hash
complete_candidate_relation_set_hash
result_status
selected_candidate_scoring_id|null
selected_relation_identity|null
proposal_evidence_set_hash
hard_gate_results
run_identity
derivation_commitment_hash
```

`derivation_commitment_hash` is computed over the canonical commitment fields other than itself.
Private chain-of-thought, hidden reasoning traces, and hidden intermediate scores MUST NOT be
recorded or requested. Auditability is provided by authenticated inputs, explicit hard-gate
results, result identities, run identities, ordering, and commitment hashes.

## 5.4 Comparison rule

Normal confirmation is legal only when both independently frozen commitments:

```text
bind the same input_bundle_hash
bind the same complete_candidate_relation_set_hash
return UNIQUE_EXISTING_OWNER_PROPOSAL
select the same non-null existing candidate_scoring_id
select the same non-null relation_identity
bind admissible proposal evidence
report every hard gate PASS
```

Any difference, missing commitment, order violation, context reuse, isolation failure, or gate
failure routes to:

```text
ESCALATE_PROPOSER_VERIFIER_DISAGREEMENT
```

No voting, averaging, confidence threshold, score reconciliation, or echo confirmation is legal.

---

# 6. B2 — human-origin provenance

The existing frozen V4 human-origin regime is reused without weakening:

```text
HUMAN_ORIGIN_PROVENANCE_MODE=CODEX_NATIVE_SESSION_USER_EVENT_PROVENANCE_V1
NATIVE_EVIDENCE_SCHEMA_HASH=0201dc07ace5189b7ae9094910b0fff0fc173e2be374ec75e0b0a658dce42f64
HUMAN_ORIGIN_CONTRACT_HASH=c1d92c96cc02495d4e4ddcc7686d0e489803a275e68bd009f2f8afab4f6a79dd
```

This regime is mandatory for every authority-bearing human event:

```text
H1 design acceptance
H2 authority activation
CONFIRM_PROPOSED_OWNER
REJECT_PROPOSAL_AND_SELECT_OTHER_EXISTING_CANDIDATE
NOT_SURE_ESCALATE
```

For each event, the machine MUST package and verify the native user-event evidence object, bind it
to the exact submitted human action and relevant proposal/authority identity, and fail closed on
ambiguity or unavailable original source records.

The following are prohibited as human-origin proof, whether alone or combined only with one
another:

```text
timestamp alone
literal hash alone
model-created or assistant-created identity
unauthenticated transcript or transcript copy
arbitrary file existence
```

The human does not create, copy, select, or manage provenance IDs. Provenance capture, packaging,
hashing, verification, and record binding are machine tasks and add no manual human step.

---

# 7. B3 — proposal-evidence admissibility

Proposal evidence is version-bound to the authenticated frozen normative substrate:

```text
V4_NORMATIVE_SOURCE_PROFILE_HASH=e24746c96c5f741cc35df8d992d93936911dd1de2ce7f1a0f00035cda3b33deb
R2_SOURCE_CLASS_FACT_TYPE_REGISTRY_ID=8cef6206dfc3581c3e7b6358bde7a36e90f4ba99078176cc0e5aff4b238298a7
R2_SOURCE_CLASS_FACT_TYPE_REGISTRY_SHA256=3df4262faa4137996d2ff8d163bcc665d5bed76b3d719e6ff66cf4154252d72f
V4_HISTORICAL_RELATION_OUTPUT_DENYLIST_HASH=f2f48a3142bf192c08cfa2bffbb722e0131bfd4a1ba55623caf5af72748b94c7
```

The denylist hash above is the canonical SHA256 of the authenticated
`BSO_EQ_HISTORICAL_RELATION_OUTPUT_DENYLIST` V4 component, independently recomputed under the
frozen canonical JSON rule and cross-checked against the authenticated V4 bundle and R2 registry.

For every primary/verifier proposal:

```text
PROPOSAL_EVIDENCE_SET ⊆ ADMISSIBLE_NORMATIVE_SOURCE_FACT_SET
```

Every proposal evidence item MUST be an exact authenticated source fact admitted by the pinned V4
profile and, where applicable, the pinned R2 field-only class-to-fact-type registry. Exact source
artifact identity, field/claim identity, authenticated value, and applicable raw/candidate binding
must be mechanically verified.

The following are prohibited as normative proposal evidence:

```text
historical or comparative relation outputs
historical disposition
candidate rank
similarity or nearest-neighbour result
occupancy or popularity
prior owner result or conclusion
positive-likelihood or recommended-candidate output
unsupported machine free-form factual assertion
```

Such material may not enter the pre-decision normative view or proposal evidence set. A machine
rationale is only a non-authoritative explanatory rendering. Every factual proposition it uses
MUST trace to exact admissible, authenticated, source-linked facts; failure of complete traceability
fails the proposal-evidence binding gate.

This evidence binding introduces no new scoring, binding, ranking, pruning, eligibility, or
tie-break semantics.

---

# 8. Hard gates and proposal statuses

Normal owner confirmation requires every gate to pass:

```text
current86_exact_scope_membership_gate
candidate_set_equality_gate
relation_set_equality_gate
source_provenance_gate
identity_binding_gate
structure_applicability_gate
scoring_authority_applicability_gate
proposal_evidence_profile_gate
proposal_evidence_binding_gate
primary_verifier_isolation_gate
primary_verifier_commitment_order_gate
primary_verifier_agreement_gate
```

Closed machine proposal/escalation statuses are:

```text
UNIQUE_EXISTING_OWNER_PROPOSAL
ESCALATE_AMBIGUOUS
ESCALATE_STRUCTURE
ESCALATE_SCORING_AUTHORITY
ESCALATE_PROVENANCE
ESCALATE_IDENTITY
ESCALATE_PROPOSER_VERIFIER_DISAGREEMENT
```

No `BEST_AVAILABLE`, `TOP_RANKED`, `MOST_SIMILAR`, blank, default, or timeout result is legal.

---

# 9. Human packet and normative actions

The compact human packet displays the authenticated raw identity/description, one admissible
source-bound proposed owner and explanation, independent agreement, hard-gate status, and a control
to expand the complete candidate universe. Machine translation is assistive only; the original
authenticated source is normative.

The closed human action vocabulary remains:

```text
CONFIRM_PROPOSED_OWNER
REJECT_PROPOSAL_AND_SELECT_OTHER_EXISTING_CANDIDATE
NOT_SURE_ESCALATE
```

There is no preselected action and no blank, missing, or timeout decision. The human is never
required to classify rejected candidates, reconstruct candidate sets, copy evidence IDs/hashes, or
package provenance.

For `REJECT_PROPOSAL_AND_SELECT_OTHER_EXISTING_CANDIDATE`, the selected candidate MUST be in the
exact frozen complete universe. Before owner freeze, that selected candidate MUST pass a fresh
proposal-evidence binding cycle and a fresh isolated primary/verifier cycle under Sections 5–8.
Validation failure routes to escalation; it does not trigger another manual evidence-ID selection.

`NOT_SURE_ESCALATE` is always legal and never forces an owner guess.

---

# 10. B4 — mutually exclusive terminal record schemas

There are exactly two terminal record classes. Each freezes an immutable result state; only one is
owner closure.

## 10.1 `A2_OWNER_ADJUDICATION_FROZEN`

Required constraints:

```text
terminal_record_class=A2_OWNER_ADJUDICATION_FROZEN
selected_owner_candidate_scoring_id != null
selected_relation_identity != null
unresolved_state=false
escalation_class=null
human_action in {
  CONFIRM_PROPOSED_OWNER,
  REJECT_PROPOSAL_AND_SELECT_OTHER_EXISTING_CANDIDATE
}
all_hard_gates=PASS
independent_commitment_comparison=PASS
human_origin_provenance_verification=PASS
```

The record binds the exact raw/scope identities, complete candidate and relation-set hashes,
proposal/input/evidence hashes, both derivation commitment hashes and run identities, selected
owner/relation identities, human action, and verified native human-origin evidence identity.

For reject/select-other, the record MUST bind the successful fresh validation cycle for the
human-selected candidate.

## 10.2 `A2_ESCALATION_FROZEN`

Required constraints:

```text
terminal_record_class=A2_ESCALATION_FROZEN
selected_owner_candidate_scoring_id=null
selected_relation_identity=null
unresolved_state=true
escalation_class != null
```

The closed escalation vocabulary is:

```text
ESCALATE_AMBIGUOUS
ESCALATE_STRUCTURE
ESCALATE_SCORING_AUTHORITY
ESCALATE_PROVENANCE
ESCALATE_IDENTITY
ESCALATE_PROPOSER_VERIFIER_DISAGREEMENT
HUMAN_NOT_SURE_ESCALATE
```

For a human `NOT_SURE_ESCALATE` event, `human_action=NOT_SURE_ESCALATE` and
`escalation_class=HUMAN_NOT_SURE_ESCALATE`, with verified native human-origin provenance.

An escalation record means only that unresolved/referral state was immutably recorded. It is not
owner adjudication, is not negative disposition, and is not owner closure.

## 10.3 Mutual exclusion and B-SO-V behavior

The two schemas are mutually exclusive: a record with any mixed nullability, unresolved state,
human action, or escalation-class shape is invalid and fails closed.

```text
B-SO-V MUST count only valid A2_OWNER_ADJUDICATION_FROZEN records as resolved owner closure.
B-SO-V MUST NOT count A2_ESCALATION_FROZEN as resolved owner closure.
B-SO-P MUST NOT publish an unresolved escalation as an owner binding.
```

Neither terminal record alone publishes a binding.

---

# 11. Authority separation and non-regression

```text
B-SO-A2=adjudication_or_escalation_state_freeze
B-SO-V=independent_closure_verification
B-SO-P=binding_publication

SCORING_AUTHORITY_MUTATION=PROHIBITED
BINDING_AUTHORITY_MUTATION_BEFORE_BSO_P=PROHIBITED
RAW_POSITIONAL_IDENTITY_MUTATION=PROHIBITED
1796_DENOMINATOR_MUTATION=PROHIBITED
ACCEPTED_BINDING_REWRITE=PROHIBITED
RETURN_TO_4161_RELATION_EQ=NO
COMPLETE_FIRST_RAW_44_FORMAL_EQ=NO
```

The existing 44-relation pilot remains non-authoritative historical design/workload evidence and
is not completed or submitted. Historical V4/R2 authority and evidence remain byte-preserved.

---

# 12. Future governance sequence (not performed)

```text
TARGETED_INDEPENDENT_DESIGN_REVIEW_R2
→ H1 explicit human accept/reject of this design
→ materialize authority candidate only if later authorized
→ independent authority verification
→ H2 explicit human activate/reject
→ only after activation, issue Current86 raw-level packets
```

H1 and H2 both require the provenance contract in Section 6. This R2 patch requests neither.

---

# 13. Design terminal state

```text
BSO_A2_TRANSITION_DESIGN_R2_PATCH=COMPLETE_DESIGN_ONLY

B1_INDEPENDENT_VERIFIER_ISOLATION=CLOSED_BY_DESIGN_PATCH
B2_HUMAN_ORIGIN_PROVENANCE=CLOSED_BY_DESIGN_PATCH
B3_PROPOSAL_EVIDENCE_ADMISSIBILITY=CLOSED_BY_DESIGN_PATCH
B4_OWNER_ESCALATION_TERMINAL_SCHEMA=CLOSED_BY_DESIGN_PATCH

AUTHORITY_MATERIALIZED=NO
SUPERSESSION_ACTIVATED=NO
H1_REQUESTED=NO
H1_PERFORMED=NO
H2_PERFORMED=NO
BSO_A2_EXECUTED=NO
REPLAY_OR_EXPERIMENT=NO
PAPER_MODIFICATION=NO
BINDING_PUBLICATION=NO

NEXT_ACTION=TARGETED_INDEPENDENT_DESIGN_REVIEW_R2
STOP_AFTER_BSO_A2_TRANSITION_DESIGN_R2_PATCH
```
