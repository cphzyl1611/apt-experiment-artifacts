# FA1B2de Current86 B-SO-A2 Prospective Authority Candidate Independent Verification Only

## Authority Boundary

This handoff authorizes `INDEPENDENT_AUTHORITY_CANDIDATE_VERIFICATION_ONLY`.
Work exclusively from the extracted handoff directory. Do not search for, read,
or depend on artifacts outside that directory.

Do not materialize or modify the candidate; activate a new authority or
supersession; publish a binding; execute B-SO-A2, B-SO-V, or B-SO-P; alter
scoring or binding authority; or create a replacement candidate. The candidate
must remain unverified and inactive after this verification session.

## Required Verification

1. Verify `FILE_LIST.txt` against every regular file in the extracted handoff
   root. The list is exhaustive and uses relative POSIX paths.
2. Run `sha256sum -c SHA256SUMS.txt` from the extracted handoff root. The
   checksum file covers every regular file except itself, as documented in
   `HANDOFF_MANIFEST.json`.
3. Verify the embedded R2 candidate checksum file and independently recompute
   the candidate manifest's component and candidate identifiers according to
   the canonicalization rules authenticated by the V4 bundle.
4. Confirm these immutable values:

   ```text
   prospective_authority_candidate_id=36831020b75a201420bd5cfce97a54ada12d44246f56a7812455bc21b99f9477
   01_transition_manifest.json sha256=4810a1b5336d1672290e46f55eae056f0d1a963f4972548f5d097d1c7dd3baae
   12_sha256sums.txt sha256=dc5ef34353243fbf6e23f1383d3f9fdd111b86080ae4e7b9b8d4140796d1c86f
   H1 evidence_id=22dbeb4700808e049ff001281caf1ae8ed5102fbcf2078991b27c0039e0dd6ba
   ```

5. Independently validate the H1 provenance evidence using
   `00_h1_native_session_capture/` and
   `FA1B2de_Current86_BSO_A2_H1_Provenance_Capture_R1/`. Treat the captured
   JSONL as the exact authenticated capture snapshot, verify its declared byte
   length and SHA-256, locate the two exact user-originated records, verify
   their ordering, literal hashes, record hashes, transcript-prefix hash, and
   canonical evidence ID under the V4 human-origin provenance contract.
6. Authenticate the exact reviewed R2 design, patch summary, R2 checksum file,
   and PASS targeted independent review against the H1 bindings.
7. Inspect the embedded frozen V4 archive and use its internal integrity
   records to independently recompute and compare the old authority lineage,
   exact Current86 86-raw scope, exact 4219-relation scope, V4 normative source
   boundary and historical-relation denylist. Authenticate the source-class and
   fact-type registry against the candidate and V4 bundle.
8. Confirm the candidate status is `PROSPECTIVE_NOT_ACTIVE`, its independent
   verification field is `false`, and all activation and binding-publication
   fields are `false`.

## Fail-Closed Result

Any missing file, checksum mismatch, scope mismatch, provenance ambiguity,
candidate-ID mismatch, source-boundary violation, or activation-state change is
a failed verification. Do not repair or regenerate artifacts. Report the
failure with the exact failing file or invariant and leave the authority
inactive.

On a successful verification, report verification evidence only. A separate,
explicit H2 human activation event is required before any activation or
supersession action.
