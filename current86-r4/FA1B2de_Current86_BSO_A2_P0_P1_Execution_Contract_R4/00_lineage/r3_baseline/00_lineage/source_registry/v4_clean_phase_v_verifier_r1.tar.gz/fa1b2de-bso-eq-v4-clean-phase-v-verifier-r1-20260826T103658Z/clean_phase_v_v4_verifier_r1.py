#!/usr/bin/env python3
"""Clean, fail-closed verifier for the FA-1B2de B-SO-EQ V4 freeze."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


REQUIRED_PRECONDITION_CHECKS = (
    "ACCEPTED_ARCHITECTURE_ARTIFACT_INTEGRITY",
    "ARCHITECTURE_HUMAN_ACCEPTANCE_PROVENANCE",
    "CURRENT86_SCOPE_EXACT_SET_EQUALITY",
    "CURRENT86_SCOPE_INDEPENDENT_RECOMPUTATION",
    "FROZEN_A_BATCH_UNCHANGED",
    "HUMAN_ORIGIN_NATIVE_SESSION_EVENT_PAIR_UNIQUENESS",
    "HUMAN_ORIGIN_NATIVE_SESSION_PREFIX_INDEPENDENT_RECOMPUTATION",
    "HUMAN_ORIGIN_PROVENANCE_EVIDENCE_INTEGRITY",
    "NO_EQ_DECISIONS_EXIST",
    "NORMATIVE_SOURCE_PROFILE_INTEGRITY",
    "POLICY_SCHEMA_BUNDLE_HUMAN_ACCEPTANCE_PROVENANCE",
    "STATIC_COMPONENT_HASH_RECOMPUTATION",
    "STATIC_MANIFEST_HASH_RECOMPUTATION",
    "UPSTREAM_AUTHORITY_APPLICABILITY",
)

PINS = {
    "architecture": "9652ecae91575df9c11e1fe217a6f7082ee2fdd84b1ca80fd4b37bfa5b782524",
    "design": "e26633b42feea119dca1f111f6b66198e749217cc7a7f1ce30ec646d9f6fdd02",
    "bundle": "7b0f71b7abdce1cc22cb584d76decb946da3fccf251b9c2c39eced7a65f5a6c9",
    "manifest": "3a191ccc0a8798e5a86ebba4976aaf4c103d84ef197d0ee4936b2f789c58ba55",
    "phase_m_contract": "f5164664c99ed1b31d64d3dd16c95e567781aa6864aa153e489dcab3afe2472b",
    "phase_v_contract": "c4a892669b139cf333d2d9b2b0214ffe70fdc99719d4c6cccd04bec2dac574c7",
    "c2r1": "29fa43904d40cb8e02466d2a7eb5437b21fb28065700386f464c54a8c3a74ea7",
    "bso_r": "eb947f385acdf8275e44cacc20d31c95080c3b1e7f7840f9fa3996a56cc64ec6",
    "frozen_a": "6be1fa70e771a66d8f0e6a70214a041428dbbd34c2a6b11fe91c29ac6ebe2225",
    "cohort": "9ac5b3ef81120be38c6b983809718fe270ee6c7140b4ad98fb0fbcc887b5cee8",
    "scoring": "18fd70d4a57f07a3e06242d9f0e077a4e6838120",
    "binding": "d309c01d6178a75cac88b6236d36179563a88239",
    "scope_contract": "47d66c784b18e7db7dde15ca1cf26773e2c1b8e90c3eafb07e505dd8da30977c",
    "provenance_contract": "c1d92c96cc02495d4e4ddcc7686d0e489803a275e68bd009f2f8afab4f6a79dd",
    "canonicalization": "b1d57c05f790a3fe7b1c1dee447ab31dd369d19491bfe413fdb0887ff4648909",
    "normative_profile": "e24746c96c5f741cc35df8d992d93936911dd1de2ce7f1a0f00035cda3b33deb",
}

R2_HASHES = {
    "static_nondrift_recheck": "7ce8dedf9598b4d32cd6b14031d8950dfd8e875b206690acf6fd9d386bbb5373",
    "native_probe": "f996c983db94b678a1c23c98e87150f464b9554781ddd15c05107d1ea2cbc8fb",
    "native_probe_independent_recompute": "60a06368fb3a7cb1510bda3663d0853011b6af23c97c4011789718f90c049624",
    "review_summary": "ac947a2998cf4742206d85afe88d2566e58bcb3ecd249d45338eafe421d86f18",
}

PLAYBOOKS = {
    "6000002": ("200ee1523cea9a8f5c4823a54ab4b6fcc263093044e2080a0ae1204501a745e8", 10),
    "6000003": ("3fdc5d901495a816ce8eb1f3b1351a4c0dfeb5032807fc0b64b6499fcd5f1bf4", 9),
    "6000006": ("e52529fb6866ab1446710731ac18d61dbd7a4d7e0766ff0edb378a6e49d1105a", 27),
    "6000007": ("5662834be1ba5e5bb44256f33ca5374e27ab8fbaeb1ec435f0227ad8459ab258", 25),
    "6000008": ("872ed4b0387968c41fceb101ef6779a8cbbe5b066d6690464b2f938f78f0162f", 15),
}

MODE = "CODEX_NATIVE_SESSION_USER_EVENT_PROVENANCE_V1"
STRENGTH = "OPERATIONAL_USER_CHANNEL_PROVENANCE_NOT_CRYPTOGRAPHIC_NON_REPUDIATION"
QUALIFICATION_SCHEMA = "BSO_EQ_HUMAN_CANDIDATE_QUALIFICATION_RECORD_SCHEMA_V2"
QUALIFICATION_FIELDS = {
    "binding_authority_identity", "bso_r_handoff_sha256", "c2r1_handoff_sha256",
    "candidate_scoring_id", "eq_human_qualification_policy_hash", "global_eq_scope_id",
    "human_eq_qualification_event_id", "human_outcome", "normative_candidate_source_evidence_bundle_id",
    "positive_basis_items", "raw_key", "raw_review_packet_id", "record_created_from_literal_human_submission",
    "record_id", "referral_affected_identity_or_evidence_ids", "referral_basis_codes", "referral_class",
    "relation_identity", "schema_version", "semantic_owner_resume_cohort_hash",
}
QUALIFICATION_OUTCOMES = {
    "DO_NOT_QUALIFY_POSITIVE_SUPPORT", "QUALIFY_POSITIVE_SUPPORT", "REVALIDATION_REQUIRED",
}


def canonical_json(value: Any) -> bytes:
    """Encode an authority object using the frozen compact JSON rules."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_hex(path.read_bytes())


def hash_without_field(value: dict[str, Any], field: str) -> str:
    copied = dict(value)
    copied.pop(field, None)
    return sha256_hex(canonical_json(copied))


def _parse_sha256sums(path: Path) -> dict[str, str]:
    entries: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        digest, separator, name = line.partition("  ")
        if not separator or len(digest) != 64 or not name or name in entries:
            raise ValueError(f"invalid SHA256SUMS entry in {path}: {line!r}")
        entries[name] = digest
    return entries


def verify_inventory(root: Path) -> dict[str, Any]:
    """Verify a package's inventory, without trusting its manifest files."""
    file_list = root / "FILE_LIST.txt"
    sums = root / "SHA256SUMS.txt"
    if not file_list.is_file() or not sums.is_file():
        return {
            "file_list_exactness": False,
            "sha256sums_exactness": False,
            "reason": "FILE_LIST.txt or SHA256SUMS.txt missing",
        }

    listed = file_list.read_text(encoding="utf-8").splitlines()
    listed_set = set(listed)
    actual_payload = sorted(
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.name not in {"FILE_LIST.txt", "SHA256SUMS.txt"}
    )
    actual_with_file_list = sorted([*actual_payload, "FILE_LIST.txt"])
    try:
        entries = _parse_sha256sums(sums)
    except ValueError as error:
        return {
            "file_list_exactness": listed in (actual_payload, actual_with_file_list) and len(listed) == len(listed_set),
            "sha256sums_exactness": False,
            "reason": str(error),
        }

    file_list_exactness = listed in (actual_payload, actual_with_file_list) and len(listed) == len(listed_set)
    expected_sums = set(actual_with_file_list)
    calculated = {name: sha256_file(root / name) for name in expected_sums if (root / name).is_file()}
    sha256sums_exactness = set(entries) == expected_sums and all(
        entries.get(name) == digest for name, digest in calculated.items()
    )
    return {
        "file_list_exactness": file_list_exactness,
        "sha256sums_exactness": sha256sums_exactness,
        "listed_file_count": len(listed),
        "actual_file_count": len(actual_payload),
        "checksum_entry_count": len(entries),
        "reason": None if file_list_exactness and sha256sums_exactness else "inventory mismatch",
    }


def write_inventory(root: Path) -> None:
    """Write the self-listed FILE_LIST and its complete checksum manifest."""
    names = sorted(
        ["FILE_LIST.txt"]
        + [
            path.relative_to(root).as_posix()
            for path in root.rglob("*")
            if path.is_file() and path.name not in {"FILE_LIST.txt", "SHA256SUMS.txt"}
        ]
    )
    (root / "FILE_LIST.txt").write_text("\n".join(names) + "\n", encoding="utf-8")
    (root / "SHA256SUMS.txt").write_text(
        "\n".join(f"{sha256_file(root / name)}  {name}" for name in names) + "\n",
        encoding="utf-8",
    )


def snapshot_before_timestamp(raw: bytes, cutoff: datetime) -> bytes:
    """Derive a historical JSONL snapshot solely from native record timestamps."""
    parts: list[bytes] = []
    for line in raw.splitlines(keepends=True):
        record = json.loads(line)
        stamp = datetime.fromisoformat(record["timestamp"].replace("Z", "+00:00"))
        if stamp > cutoff:
            break
        parts.append(line)
    if not parts:
        raise ValueError("native source contains no records at or before the cutoff")
    return b"".join(parts)


def precondition_checks(checks: dict[str, bool]) -> list[dict[str, str]]:
    """Encode the frozen exact-once check set, rejecting omissions and additions."""
    if set(checks) != set(REQUIRED_PRECONDITION_CHECKS):
        raise ValueError("freeze precondition checks are not the exact required set")
    if not all(checks.values()):
        raise ValueError("freeze precondition check failed")
    return [{"check_name": name, "result": "PASS"} for name in sorted(checks)]


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def _safe_member_path(destination: Path, name: str) -> Path:
    candidate = Path(name)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError("archive member path escapes extraction root")
    target = (destination / candidate).resolve()
    root = destination.resolve()
    if target != root and root not in target.parents:
        raise ValueError("archive member path escapes extraction root")
    return target


def _verify_nested_inventory(root: Path) -> dict[str, Any]:
    """Verify flat and hierarchical archive FILE_LIST/SHA256SUMS inventories."""
    file_list_path = root / "FILE_LIST.txt"
    sums_path = root / "SHA256SUMS.txt"
    if not file_list_path.is_file() or not sums_path.is_file():
        raise ValueError("archive payload lacks root inventory files")

    def listed(path: Path, direct: bool = False) -> list[str]:
        values = [line for line in path.read_text(encoding="utf-8").splitlines() if line]
        if len(values) != len(set(values)) or any(Path(value).is_absolute() or ".." in Path(value).parts for value in values):
            raise ValueError("invalid FILE_LIST entry")
        if direct and any(len(Path(value).parts) != 1 for value in values):
            raise ValueError("nested FILE_LIST contains a non-direct entry")
        return values

    def verify_sums(directory: Path, checksum_path: Path, expected: set[str]) -> None:
        entries = _parse_sha256sums(checksum_path)
        if set(entries) != expected:
            raise ValueError("SHA256SUMS target set differs from inventory")
        for name in sorted(entries):
            if not (directory / name).is_file() or sha256_file(directory / name) != entries[name]:
                raise ValueError(f"SHA256SUMS mismatch: {name}")

    all_files = sorted(path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file())
    nested_lists = sorted(path for path in root.rglob("FILE_LIST.txt") if path.parent != root)
    nested_sums = sorted(path for path in root.rglob("SHA256SUMS.txt") if path.parent != root)
    if {path.parent for path in nested_lists} != {path.parent for path in nested_sums}:
        raise ValueError("nested inventory manifests are not paired")

    root_list = listed(file_list_path)
    root_non_sums = sorted(name for name in all_files if name != "SHA256SUMS.txt")
    root_payload = sorted(name for name in root_non_sums if name != "FILE_LIST.txt")
    if nested_lists:
        expected_payload = sorted(name for name in all_files if Path(name).name not in {"FILE_LIST.txt", "SHA256SUMS.txt"})
        if root_list != expected_payload:
            raise ValueError("hierarchical root FILE_LIST is not exact")
        for nested_list in nested_lists:
            directory = nested_list.parent
            direct_files = {path.name for path in directory.iterdir() if path.is_file()}
            nested_expected = direct_files - {"SHA256SUMS.txt"}
            if set(listed(nested_list, direct=True)) != nested_expected:
                raise ValueError("nested FILE_LIST is not exact")
            verify_sums(directory, directory / "SHA256SUMS.txt", nested_expected)
        root_targets = set(expected_payload) | {"FILE_LIST.txt"}
        mode = "HIERARCHICAL"
    elif root_list == root_non_sums:
        root_targets = set(root_non_sums)
        mode = "SELF_LISTED"
    elif root_list == root_payload:
        root_targets = set(root_non_sums)
        mode = "PAYLOAD_ONLY_LIST"
    else:
        raise ValueError("root FILE_LIST is not exact")
    verify_sums(root, sums_path, root_targets)
    return {
        "file_list_exactness": "PASS",
        "sha256sums_exactness": "PASS",
        "inventory_mode": mode,
        "listed_file_count": len(root_list),
        "checksum_entry_count": len(root_targets),
        "nested_inventory_directory_count": len(nested_lists),
        "nested_inventory_directories": [path.parent.relative_to(root).as_posix() for path in nested_lists],
    }


def extract_and_authenticate_archive(archive: Path, destination: Path, expected_sha256: str) -> dict[str, Any]:
    if destination.exists():
        raise ValueError("fresh extraction destination already exists")
    actual_sha256 = sha256_file(archive)
    if actual_sha256 != expected_sha256:
        raise ValueError("archive SHA256 does not match its frozen pin")
    destination.mkdir(parents=True)
    with tarfile.open(archive, "r:gz") as handle:
        members = handle.getmembers()
        for member in members:
            target = _safe_member_path(destination, member.name)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif member.isreg():
                target.parent.mkdir(parents=True, exist_ok=True)
                source = handle.extractfile(member)
                if source is None:
                    raise ValueError("archive regular member cannot be read")
                with target.open("wb") as output:
                    shutil.copyfileobj(source, output)
            else:
                raise ValueError("archive contains unsupported non-regular member")
    candidates = sorted(destination.rglob("FILE_LIST.txt"), key=lambda path: (len(path.relative_to(destination).parts), str(path)))
    if not candidates:
        raise ValueError("archive contains no FILE_LIST.txt")
    payload_root = candidates[0].parent
    report = _verify_nested_inventory(payload_root)
    report.update({
        "archive_path": str(archive),
        "archive_sha256": actual_sha256,
        "archive_size_bytes": archive.stat().st_size,
        "fresh_extraction_directory": str(destination),
        "payload_root": str(payload_root),
    })
    return report


def authenticate_v4_static(package_root: Path) -> dict[str, Any]:
    frozen = package_root / "00_frozen_v4"
    paths = {
        "architecture": frozen / "Design_FA1B2de_BSO_EQ_Candidate_Level_Human_Qualification_Workflow_CURRENT86_FINAL_PATCHED.md",
        "design": frozen / "Design_FA1B2de_BSO_EQ_Human_Origin_Provenance_Interface_V4.md",
        "bundle": frozen / "BSO_EQ_Candidate_Level_Policy_Schema_Authority_Bundle_PROSPECTIVE_v4.json",
    }
    actual = {name: sha256_file(path) for name, path in paths.items()}
    if actual != {name: PINS[name] for name in paths}:
        raise ValueError("frozen V4 file identity mismatch")
    bundle = load_json(paths["bundle"])
    objects = bundle.get("component_objects")
    recorded = bundle.get("component_object_sha256")
    manifest = bundle.get("static_policy_schema_authority_manifest")
    if not isinstance(objects, dict) or not isinstance(recorded, dict) or not isinstance(manifest, dict):
        raise ValueError("frozen V4 bundle lacks static authority objects")
    recomputed = {name: sha256_hex(canonical_json(value)) for name, value in objects.items()}
    manifest_hash = sha256_hex(canonical_json(manifest))
    component_pass = len(objects) == 36 and recomputed == recorded
    manifest_pass = (
        manifest_hash == PINS["manifest"]
        and bundle.get("static_policy_schema_authority_manifest_sha256") == PINS["manifest"]
    )
    if not component_pass or not manifest_pass:
        raise ValueError("V4 component or static-manifest recomputation failed")
    return {
        "schema_version": "FA1B2DE_BSO_EQ_V4_INDEPENDENT_STATIC_RECOMPUTATION_R1",
        "status": "PASS",
        "accepted_workflow_architecture_sha256": actual["architecture"],
        "accepted_v4_design_sha256": actual["design"],
        "accepted_v4_bundle_sha256": actual["bundle"],
        "component_count": len(recomputed),
        "component_sha256": recomputed,
        "static_authority_manifest_sha256": manifest_hash,
        "static_component_recomputation": "PASS",
        "static_manifest_recomputation": "PASS",
    }


def authenticate_r2_evidence(package_root: Path) -> dict[str, Any]:
    root = package_root / "01_r2_pass_evidence"
    paths = {
        "static_nondrift_recheck": root / "v4_r2_static_authority_nondrift_recheck.json",
        "native_probe": root / "v4_r2_native_session_provenance_interface_probe.json",
        "native_probe_independent_recompute": root / "v4_r2_native_session_provenance_interface_probe_independent_recompute.json",
        "review_summary": root / "v4_r2_review_summary.md",
    }
    actual = {name: sha256_file(path) for name, path in paths.items()}
    if actual != R2_HASHES:
        raise ValueError("R2 evidence file hash mismatch")
    static = load_json(paths["static_nondrift_recheck"])
    probe = load_json(paths["native_probe"])
    independent = load_json(paths["native_probe_independent_recompute"])
    summary = paths["review_summary"].read_text(encoding="utf-8")
    checks = static.get("checks")
    valid = (
        static.get("review_result") == "PASS" and isinstance(checks, dict) and bool(checks) and all(checks.values())
        and probe.get("probe_result") == "PASS" and probe.get("diagnostic_only") == "YES"
        and probe.get("not_human_acceptance") == "YES" and probe.get("not_authority_binding") == "YES"
        and probe.get("event_match", {}).get("native_user_role_assertion_verified") is True
        and probe.get("literal_integrity", {}).get("marker_byte_exact_match") is True
        and probe.get("literal_integrity", {}).get("invocation_byte_exact_match") is True
        and probe.get("transcript_prefix", {}).get("prefix_ends_at_invocation_record") is True
        and probe.get("evidence_id_recomputation") == "PASS"
        and probe.get("independent_double_parse", {}).get("all_required_fields_equal") is True
        and independent.get("all_required_fields_equal") is True
        and "V4_HUMAN_ACCEPTANCE_PERFORMED=NO" in summary
        and "WORKFLOW_ARCHITECTURE_AUTHORITY_HASH=NOT_FROZEN" in summary
    )
    if not valid:
        raise ValueError("R2 evidence content is not a PASS")
    return {"schema_version": "FA1B2DE_BSO_EQ_V4_R2_APPLICABILITY_R1", "status": "PASS", "artifact_sha256": actual}


def raw_key_sort(raw_key: str) -> tuple[int, int, int]:
    match = re.fullmatch(r"(\d+)::S(\d+)::A(\d+)", raw_key)
    if match is None:
        raise ValueError(f"invalid raw action key: {raw_key}")
    return tuple(int(part) for part in match.groups())


def make_relation_identity(raw_key: str, scoring_id: str) -> str:
    if re.fullmatch(r"[0-9a-f]{64}", scoring_id) is None:
        raise ValueError("candidate scoring identity has invalid format")
    return sha256_hex(canonical_json({
        "schema": "BSO_EQ_RELATION_IDENTITY_PAYLOAD_V1",
        "raw_key": raw_key,
        "candidate_scoring_id": scoring_id,
    }))


def rebuild_relations_primary(packet_paths: dict[str, Path]) -> list[dict[str, str]]:
    """Build current86 relation membership through direct structured packet traversal."""
    if set(packet_paths) != set(PLAYBOOKS):
        raise ValueError("current86 playbook packet set mismatch")
    relations: list[dict[str, str]] = []
    for playbook_id, (expected_hash, expected_raw_count) in PLAYBOOKS.items():
        packet_path = packet_paths[playbook_id]
        if sha256_file(packet_path) != expected_hash:
            raise ValueError(f"packet hash mismatch: {playbook_id}")
        packet = load_json(packet_path)
        records = packet.get("records") if isinstance(packet, dict) else None
        if not isinstance(records, list) or len(records) != expected_raw_count:
            raise ValueError(f"packet raw count mismatch: {playbook_id}")
        for record in records:
            if not isinstance(record, dict):
                raise ValueError("packet record must be an object")
            context = record.get("raw_context")
            candidates = record.get("candidates_deterministic_non_recommendation_order")
            if not isinstance(context, dict) or not isinstance(context.get("raw_action_key"), str) or not isinstance(candidates, list):
                raise ValueError("packet record lacks current86 relation inputs")
            raw_key = context["raw_action_key"]
            raw_key_sort(raw_key)
            for candidate in candidates:
                if not isinstance(candidate, dict):
                    raise ValueError("candidate must be an object")
                encoded = candidate.get("candidate_scoring_id")
                if not isinstance(encoded, str) or not encoded.startswith("scoring:"):
                    raise ValueError("candidate scoring ID lacks scoring: prefix")
                scoring_id = encoded[len("scoring:"):]
                relations.append({
                    "raw_key": raw_key,
                    "candidate_scoring_id": scoring_id,
                    "relation_identity": make_relation_identity(raw_key, scoring_id),
                    "disposition": "PREEXISTING_AUTHENTICATED_HARD_NEGATIVE"
                    if candidate.get("hard_negative_status") == "EXCLUDED" else "HUMAN_EQ_REVIEW_REQUIRED",
                })
    relations.sort(key=lambda item: (raw_key_sort(item["raw_key"]), item["candidate_scoring_id"]))
    if len({(item["raw_key"], item["candidate_scoring_id"]) for item in relations}) != len(relations):
        raise ValueError("duplicate current86 raw/candidate relation")
    return relations


def rebuild_relations_independent(packet_paths: dict[str, Path]) -> list[dict[str, str]]:
    """Rebuild relations with independent parsing and identity construction code."""
    if sorted(packet_paths) != sorted(PLAYBOOKS):
        raise ValueError("independent current86 playbook packet set mismatch")
    by_key: dict[tuple[str, str], dict[str, Any]] = {}
    for playbook_id, expected in sorted(PLAYBOOKS.items()):
        packet_data = packet_paths[playbook_id].read_bytes()
        if hashlib.sha256(packet_data).hexdigest() != expected[0]:
            raise ValueError(f"independent packet digest mismatch: {playbook_id}")
        parsed = json.loads(packet_data.decode("utf-8"))
        records = parsed.get("records") if isinstance(parsed, dict) else None
        if not isinstance(records, list) or len(records) != expected[1]:
            raise ValueError(f"independent packet shape mismatch: {playbook_id}")
        for record_index in range(len(records)):
            record = records[record_index]
            try:
                raw = record["raw_context"]["raw_action_key"]
                candidates = record["candidates_deterministic_non_recommendation_order"]
            except (KeyError, TypeError) as error:
                raise ValueError("independent relation parser found malformed packet record") from error
            match = re.fullmatch(r"(\d+)::S(\d+)::A(\d+)", raw) if isinstance(raw, str) else None
            if match is None or not isinstance(candidates, list):
                raise ValueError("independent relation parser found invalid relation inputs")
            raw_sort_key = tuple(int(value) for value in match.groups())
            for candidate_index in range(len(candidates)):
                candidate = candidates[candidate_index]
                if not isinstance(candidate, dict):
                    raise ValueError("independent relation parser found non-object candidate")
                encoded = candidate.get("candidate_scoring_id")
                if not isinstance(encoded, str) or not encoded.startswith("scoring:"):
                    raise ValueError("independent relation parser found invalid candidate identity")
                scoring = encoded[8:]
                if re.fullmatch(r"[0-9a-f]{64}", scoring) is None:
                    raise ValueError("independent relation parser found malformed scoring identity")
                key = (raw, scoring)
                if key in by_key:
                    raise ValueError("independent relation parser found duplicate relation")
                relation = hashlib.sha256(json.dumps({
                    "schema": "BSO_EQ_RELATION_IDENTITY_PAYLOAD_V1",
                    "raw_key": raw,
                    "candidate_scoring_id": scoring,
                }, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
                by_key[key] = {
                    "raw_key": raw,
                    "candidate_scoring_id": scoring,
                    "relation_identity": relation,
                    "disposition": "PREEXISTING_AUTHENTICATED_HARD_NEGATIVE"
                    if candidate.get("hard_negative_status") == "EXCLUDED" else "HUMAN_EQ_REVIEW_REQUIRED",
                    "_raw_sort": raw_sort_key,
                }
    result: list[dict[str, str]] = []
    for key in sorted(by_key, key=lambda item: (by_key[item]["_raw_sort"], item[1])):
        relation = by_key[key]
        relation.pop("_raw_sort")
        result.append(relation)
    return result


def build_current86_scope(relations: list[dict[str, str]]) -> dict[str, Any]:
    raw_keys = sorted({item["raw_key"] for item in relations}, key=raw_key_sort)
    hard_negative_ids = sorted(item["relation_identity"] for item in relations if item["disposition"] == "PREEXISTING_AUTHENTICATED_HARD_NEGATIVE")
    human_review_ids = sorted(item["relation_identity"] for item in relations if item["disposition"] == "HUMAN_EQ_REVIEW_REQUIRED")
    all_ids = {item["relation_identity"] for item in relations}
    valid = (
        len(raw_keys) == 86 and len(relations) == 4219 and len(hard_negative_ids) == 58 and len(human_review_ids) == 4161
        and len(all_ids) == len(relations) and not (set(hard_negative_ids) & set(human_review_ids))
        and set(hard_negative_ids) | set(human_review_ids) == all_ids
        and all(item["relation_identity"] == make_relation_identity(item["raw_key"], item["candidate_scoring_id"]) for item in relations)
    )
    if not valid:
        raise ValueError("current86 scope conservation or identity check failed")
    scope = {
        "binding_authority_baseline": PINS["binding"],
        "bso_r_handoff_sha256": PINS["bso_r"],
        "c2r1_handoff_sha256": PINS["c2r1"],
        "historical_bso_a_batch_scope_hash": PINS["frozen_a"],
        "human_review_required_relation_ids": human_review_ids,
        "playbook_ids": list(PLAYBOOKS),
        "preexisting_hard_negative_relation_ids": hard_negative_ids,
        "project_scoring_authority": PINS["scoring"],
        "raw_keys": raw_keys,
        "relation_membership": relations,
        "schema_version": "BSO_EQ_CURRENT86_SCOPE_RUNTIME_SCHEMA_V2",
        "scope_contract_hash": PINS["scope_contract"],
        "scope_id": "",
        "semantic_owner_resume_cohort_hash": PINS["cohort"],
    }
    scope["scope_id"] = hash_without_field(scope, "scope_id")
    return scope


def find_unique_archive_by_sha256(artifact_root: Path, expected_sha256: str) -> Path:
    matches = [path for path in sorted(artifact_root.rglob("*.tar.gz")) if sha256_file(path) == expected_sha256]
    if len(matches) != 1:
        raise ValueError(f"expected exactly one archive for {expected_sha256}; found {len(matches)}")
    return matches[0]


def recompute_frozen_a_batch(artifact_root: Path) -> dict[str, Any]:
    candidates = []
    for path in artifact_root.rglob("bso_a_batch_scope_hash.json"):
        try:
            declared = load_json(path)
            scope_path = path.parent / declared["scope_file"]
            scope = load_json(scope_path)
            computed = sha256_hex(canonical_json(scope))
            if declared.get("BSO_A_BATCH_SCOPE_HASH") == PINS["frozen_a"]:
                candidates.append((path, scope_path, computed, declared))
        except (OSError, KeyError, TypeError, json.JSONDecodeError):
            continue
    if len(candidates) != 1:
        raise ValueError(f"expected exactly one frozen A-batch source object; found {len(candidates)}")
    declaration, scope_path, computed, declared = candidates[0]
    if computed != PINS["frozen_a"] or declared.get("canonicalization") != "sha256-canonical-json-v1":
        raise ValueError("frozen A-batch scope self-hash mismatch")
    return {
        "schema_version": "FA1B2DE_BSO_EQ_V4_FROZEN_A_BATCH_RECOMPUTATION_R1",
        "status": "PASS",
        "source_declaration_path": str(declaration),
        "source_scope_path": str(scope_path),
        "declared_frozen_a_batch_hash": declared["BSO_A_BATCH_SCOPE_HASH"],
        "recomputed_frozen_a_batch_hash": computed,
        "frozen_a_batch_unchanged": True,
    }


def rematerialize_upstream_scope(artifact_root: Path, workspace_parent: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    c2_archive = find_unique_archive_by_sha256(artifact_root, PINS["c2r1"])
    bso_archive = find_unique_archive_by_sha256(artifact_root, PINS["bso_r"])
    fresh_root = Path(tempfile.mkdtemp(prefix="fa1b2de-clean-phase-v-upstream-", dir=workspace_parent))
    try:
        c2 = extract_and_authenticate_archive(c2_archive, fresh_root / "c2r1", PINS["c2r1"])
        bso = extract_and_authenticate_archive(bso_archive, fresh_root / "bso_r", PINS["bso_r"])
        c2_root, bso_root = Path(c2["payload_root"]), Path(bso["payload_root"])
        c2_summary = load_json(c2_root / "c2r1_summary.json")
        bso_summary = load_json(bso_root / "bso_r_summary.json")
        cohort = load_json(bso_root / "bso_r_semantic_owner_cohort_manifest.json")
        upstream_pass = (
            c2_summary.get("phase_verdict") == "PASS_FA1B2DE_C2R1_SUBSTANTIVE_DE_BINDING_REVALIDATION"
            and c2_summary.get("repository_unchanged") is True and c2_summary.get("no_publication") is True
            and bso_summary.get("BSO_R_PHASE_VERDICT") == "PASS_FA1B2DE_BSO_R_EVIDENCE_RECONSTRUCTION"
            and bso_summary.get("BSO_R_REVIEW_STATUS") == "PASS_TRIAGE_COMPLETE"
            and bso_summary.get("DETERMINISTIC_REBUILD") == "PASS"
            and bso_summary.get("PROJECT_SCORING_AUTHORITY") == PINS["scoring"]
            and bso_summary.get("PROJECT_BINDING_AUTHORITY_BASELINE") == PINS["binding"]
            and cohort.get("semantic_owner_resume_cohort_hash") == PINS["cohort"]
        )
        if not upstream_pass:
            raise ValueError("upstream C2-R1/BSO-R applicability is not a PASS")
        packets = {key: bso_root / "bso_r_playbook_review_packets" / f"playbook_{key}.json" for key in PLAYBOOKS}
        primary = rebuild_relations_primary(packets)
        independent = rebuild_relations_independent(packets)
        if primary != independent:
            raise ValueError("independent current86 relation reconstruction differs from primary")
        scope = build_current86_scope(primary)
        upstream = {
            "schema_version": "FA1B2DE_BSO_EQ_V4_UPSTREAM_EXTRACTION_AUTHENTICATION_R1",
            "status": "PASS",
            "fresh_verifier_workspace": str(fresh_root),
            "archive_discovery": {
                "c2r1": {"path": str(c2_archive), "sha256": sha256_file(c2_archive)},
                "bso_r": {"path": str(bso_archive), "sha256": sha256_file(bso_archive)},
            },
            "fresh_extraction": {"c2r1": c2, "bso_r": bso},
            "upstream_applicability": "PASS",
            "primary_independent_relation_set_equality": "PASS",
            "packet_manifest": {
                key: {"sha256": sha256_file(path), "raw_count": PLAYBOOKS[key][1], "archive_member_path": f"bso_r_playbook_review_packets/playbook_{key}.json"}
                for key, path in packets.items()
            },
        }
        return scope, upstream
    finally:
        shutil.rmtree(fresh_root)


def _user_event_primary(record: dict[str, Any], line_no: int, line_end: int, raw_line: bytes) -> dict[str, Any] | None:
    payload = record.get("payload", {})
    item = payload.get("item", {}) if isinstance(payload, dict) else {}
    if not isinstance(item, dict) or item.get("type") != "UserMessage":
        return None
    content = item.get("content", [])
    text = "".join(
        chunk.get("text", "") for chunk in content
        if isinstance(chunk, dict) and chunk.get("type") == "text" and isinstance(chunk.get("text"), str)
    ) if isinstance(content, list) else ""
    return {
        "ordinal": record.get("ordinal"), "line_no": line_no, "line_end": line_end,
        "literal": text.encode("utf-8"), "native_record_sha256": sha256_hex(raw_line),
        "role_field_path": "payload.item.type", "role_value": item.get("type"),
    }


def parse_native_primary(raw: bytes, source_path: Path) -> dict[str, Any]:
    events: list[dict[str, Any]] = []
    session_id = None
    offset = 0
    for line_no, line in enumerate(raw.splitlines(keepends=True), 1):
        record = json.loads(line)
        payload = record.get("payload", {})
        if isinstance(payload, dict) and isinstance(payload.get("session_id"), str):
            session_id = payload["session_id"]
        event = _user_event_primary(record, line_no, offset + len(line), line)
        if event is not None:
            events.append(event)
        offset += len(line)
    return {"source_path": str(source_path), "raw": raw, "session_id": session_id, "events": events}


def parse_native_byte_scanner(raw: bytes, source_path: Path) -> dict[str, Any]:
    """A separate byte-delimited parser for native Codex rollout records."""
    events: list[dict[str, Any]] = []
    session_id = None
    start = 0
    line_no = 0
    while start < len(raw):
        newline = raw.find(b"\n", start)
        end = len(raw) if newline < 0 else newline + 1
        line_no += 1
        line = raw[start:end]
        record = json.loads(line.decode("utf-8"))
        payload = record.get("payload")
        if isinstance(payload, dict) and isinstance(payload.get("session_id"), str):
            session_id = payload["session_id"]
        item = payload.get("item") if isinstance(payload, dict) else None
        if isinstance(item, dict) and item.get("type") == "UserMessage":
            chunks = item.get("content")
            fragments: list[str] = []
            if isinstance(chunks, list):
                for chunk in chunks:
                    if isinstance(chunk, dict) and chunk.get("type") == "text" and isinstance(chunk.get("text"), str):
                        fragments.append(chunk["text"])
            events.append({
                "ordinal": record.get("ordinal"), "line_no": line_no, "line_end": end,
                "literal": "".join(fragments).encode("utf-8"), "native_record_sha256": hashlib.sha256(line).hexdigest(),
                "role_field_path": "payload.item.type", "role_value": item.get("type"),
            })
        start = end
    return {"source_path": str(source_path), "raw": raw, "session_id": session_id, "events": events}


def select_native_pair(parsed: dict[str, Any], authorization: bytes, invocation: bytes) -> dict[str, Any] | None:
    authorizations = [event for event in parsed["events"] if event["literal"] == authorization]
    invocations = [event for event in parsed["events"] if event["literal"] == invocation]
    if len(authorizations) != 1 or len(invocations) != 1 or not isinstance(parsed.get("session_id"), str):
        return None
    authorization_event, invocation_event = authorizations[0], invocations[0]
    if not isinstance(authorization_event.get("ordinal"), int) or not isinstance(invocation_event.get("ordinal"), int):
        return None
    if authorization_event["ordinal"] >= invocation_event["ordinal"]:
        return None
    return {
        "source_file": parsed["source_path"], "source_file_sha256": sha256_hex(parsed["raw"]),
        "source_file_size_bytes": len(parsed["raw"]), "session_id": parsed["session_id"],
        "authorization": authorization_event, "invocation": invocation_event,
        "prefix_sha256": sha256_hex(parsed["raw"][:invocation_event["line_end"]]),
        "authorization_match_count": len(authorizations), "invocation_match_count": len(invocations),
    }


def _marker_in_raw(raw: bytes, literal: bytes) -> bool:
    if literal in raw:
        return True
    try:
        return json.dumps(literal.decode("utf-8"), ensure_ascii=False)[1:-1].encode("utf-8") in raw
    except UnicodeDecodeError:
        return False


def _first_native_timestamp(raw: bytes) -> datetime:
    record = json.loads(raw.splitlines(keepends=False)[0])
    return datetime.fromisoformat(record["timestamp"].replace("Z", "+00:00"))


def discover_native_provenance(handoff: Path, authorization: bytes, invocation: bytes) -> dict[str, Any]:
    root = Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))) / "sessions"
    if not root.is_dir():
        raise ValueError("native Codex session root is unavailable")
    cutoff = datetime.fromtimestamp(handoff.stat().st_mtime, tz=timezone.utc)
    all_files = sorted(root.rglob("rollout-*.jsonl"))
    eligible: list[Path] = []
    primary_current: dict[Path, dict[str, Any]] = {}
    secondary_current: dict[Path, dict[str, Any]] = {}
    parse_failures: list[dict[str, str]] = []
    for path in all_files:
        raw = path.read_bytes()
        try:
            created = _first_native_timestamp(raw)
            is_eligible = created <= cutoff
            parsed_a = parse_native_primary(raw, path)
            parsed_b = parse_native_byte_scanner(raw, path)
        except (UnicodeDecodeError, json.JSONDecodeError, KeyError, IndexError, ValueError) as error:
            if _marker_in_raw(raw, authorization) or _marker_in_raw(raw, invocation):
                raise ValueError(f"malformed native source contains a required provenance literal: {path}") from error
            name_match = re.search(r"rollout-(\d{4}-\d{2}-\d{2})T", path.name)
            is_eligible = bool(name_match and name_match.group(1) <= cutoff.date().isoformat())
            parsed_a = parsed_b = None
            parse_failures.append({"path": str(path), "error_type": type(error).__name__})
        if is_eligible:
            eligible.append(path)
        if parsed_a is not None:
            primary_current[path] = parsed_a
            secondary_current[path] = parsed_b

    primary_matches = [select_native_pair(value, authorization, invocation) for value in primary_current.values()]
    secondary_matches = [select_native_pair(value, authorization, invocation) for value in secondary_current.values()]
    primary_matches = [value for value in primary_matches if value is not None]
    secondary_matches = [value for value in secondary_matches if value is not None]
    if len(primary_matches) != 1 or len(secondary_matches) != 1:
        raise ValueError("global native session discovery did not find exactly one matching pair")
    current_a, current_b = primary_matches[0], secondary_matches[0]
    if current_a["source_file"] != current_b["source_file"]:
        raise ValueError("independent parsers selected different native source files")
    source_path = Path(current_a["source_file"])
    snapshot = snapshot_before_timestamp(source_path.read_bytes(), cutoff)
    snapshot_a = select_native_pair(parse_native_primary(snapshot, source_path), authorization, invocation)
    snapshot_b = select_native_pair(parse_native_byte_scanner(snapshot, source_path), authorization, invocation)
    if snapshot_a is None or snapshot_b is None:
        raise ValueError("native historical snapshot lacks the required ordered user-event pair")
    event_fields = ("ordinal", "line_no", "line_end", "literal", "native_record_sha256", "role_field_path", "role_value")
    equality = {
        "native_session_id": snapshot_a["session_id"] == snapshot_b["session_id"],
        "source_file": snapshot_a["source_file"] == snapshot_b["source_file"],
        "source_file_sha256": snapshot_a["source_file_sha256"] == snapshot_b["source_file_sha256"],
        "source_file_size_bytes": snapshot_a["source_file_size_bytes"] == snapshot_b["source_file_size_bytes"],
        "prefix_sha256": snapshot_a["prefix_sha256"] == snapshot_b["prefix_sha256"],
        **{f"authorization.{field}": snapshot_a["authorization"][field] == snapshot_b["authorization"][field] for field in event_fields},
        **{f"invocation.{field}": snapshot_a["invocation"][field] == snapshot_b["invocation"][field] for field in event_fields},
    }
    if not all(equality.values()):
        raise ValueError("primary and byte-scanner provenance reconstructions differ")
    snapshot_a.update({
        "matching_session_file_count": 1,
        "native_session_candidate_file_count": len(eligible),
        "native_session_parse_failure_file_count": len(parse_failures),
        "native_session_parse_failure_paths": [failure["path"] for failure in parse_failures],
        "native_session_store_root": str(root),
        "archive_mtime_cutoff_utc": cutoff.isoformat(),
        "parser_equality_fields": equality,
    })
    return snapshot_a


def acceptance_semantics(authorization: bytes, invocation: bytes, package_root: Path) -> dict[str, Any]:
    contract_path = package_root / "03_contracts" / "Prompt_FA1B2de_BSO_EQ_V4_Phase_M_Remediation_R1_Current86.md"
    architecture_path = package_root / "00_frozen_v4" / "Design_FA1B2de_BSO_EQ_Candidate_Level_Human_Qualification_Workflow_CURRENT86_FINAL_PATCHED.md"
    architecture_bytes = architecture_path.read_bytes()
    checks = {
        "architecture_sha": PINS["architecture"].encode() in authorization,
        "architecture_name": (
            sha256_hex(architecture_bytes) == PINS["architecture"]
            and b"RAW_LOCAL_CANDIDATE_COMPLETE_EQ_REVIEW_WITH_MULTI_RAW_SUBMISSION" in architecture_bytes
        ),
        "v4_design_sha": PINS["design"].encode() in authorization,
        "v4_bundle_sha": PINS["bundle"].encode() in authorization,
        "v4_manifest_sha": PINS["manifest"].encode() in authorization,
        "component_count": b"ACCEPTED_STATIC_COMPONENT_COUNT =\n36" in authorization,
        "provenance_mode": MODE.encode() in authorization,
        "phase_m_authorization": PINS["phase_m_contract"].encode() in authorization,
        "phase_v_authorization": PINS["phase_v_contract"].encode() in authorization,
        "phase_m_contract_file": sha256_file(contract_path) == PINS["phase_m_contract"],
        "acceptance_does_not_freeze": b"This authorization does NOT itself freeze authority" in authorization,
        "eq_unauthorized": b"EQ_EXECUTION_AUTHORIZED =\nNO" in authorization,
        "qualification_unauthorized": b"HUMAN_CANDIDATE_QUALIFICATION_AUTHORIZED =\nNO" in authorization,
        "positive_support_unauthorized": b"POSITIVE_SUPPORT_CREATION_AUTHORIZED =\nNO" in authorization,
        "bso_a_unauthorized": b"BSO_A_ADJUDICATION_AUTHORIZED =\nNO" in authorization,
        "invocation_binds_authorization": PINS["phase_m_contract"].encode() in invocation and b"AUTHORIZATION_SHA256=" in invocation,
        "no_terminal_newline": not authorization.endswith((b"\n", b"\r")) and not invocation.endswith((b"\n", b"\r")),
    }
    if not all(checks.values()):
        raise ValueError("acceptance semantics are not all explicit")
    return {
        "schema_version": "FA1B2DE_BSO_EQ_V4_ACCEPTANCE_SEMANTICS_R1",
        "status": "PASS", "authorization_sha256": sha256_hex(authorization), "invocation_sha256": sha256_hex(invocation),
        "acceptance_semantics_checks": checks, "acceptance_semantics_all_explicit": True,
    }


def build_provenance_evidence(pair: dict[str, Any], authorization: bytes, invocation: bytes) -> tuple[dict[str, Any], dict[str, str]]:
    evidence = {
        "accepted_architecture_artifact_sha256": PINS["architecture"],
        "accepted_policy_schema_bundle_file_sha256": PINS["bundle"],
        "accepted_static_authority_manifest_sha256": PINS["manifest"],
        "evidence_id": "",
        "invocation_event_ordinal": pair["invocation"]["ordinal"],
        "invocation_exact_match_count_after_reattestation": pair["invocation_match_count"],
        "invocation_literal_utf8": invocation.decode("utf-8"),
        "invocation_literal_utf8_length_bytes": len(invocation),
        "invocation_literal_utf8_sha256": sha256_hex(invocation),
        "invocation_native_record_sha256": pair["invocation"]["native_record_sha256"],
        "invocation_user_role_assertion_exact_value": pair["invocation"]["role_value"],
        "invocation_user_role_assertion_field_path": pair["invocation"]["role_field_path"],
        "matching_session_file_count": pair["matching_session_file_count"],
        "materializer_or_review_contract_sha256": PINS["phase_m_contract"],
        "native_session_candidate_file_count": pair["native_session_candidate_file_count"],
        "native_session_parse_failure_file_count": pair["native_session_parse_failure_file_count"],
        "native_session_parse_failure_paths": pair["native_session_parse_failure_paths"],
        "native_session_id": pair["session_id"],
        "native_session_id_exact_value": pair["session_id"],
        "native_session_id_source_field_path": "payload.session_id",
        "native_session_record_format": "Codex rollout JSONL (one JSON object per line)",
        "native_session_record_locator": pair["source_file"],
        "native_session_store_root": pair["native_session_store_root"],
        "native_source_file_sha256_at_capture": pair["source_file_sha256"],
        "native_source_file_size_bytes_at_capture": pair["source_file_size_bytes"],
        "provenance_mode": MODE,
        "provenance_strength": STRENGTH,
        "reattestation_event_ordinal": pair["authorization"]["ordinal"],
        "reattestation_exact_match_count_in_session": pair["authorization_match_count"],
        "reattestation_literal_utf8": authorization.decode("utf-8"),
        "reattestation_literal_utf8_length_bytes": len(authorization),
        "reattestation_literal_utf8_sha256": sha256_hex(authorization),
        "reattestation_native_record_sha256": pair["authorization"]["native_record_sha256"],
        "reattestation_user_role_assertion_exact_value": pair["authorization"]["role_value"],
        "reattestation_user_role_assertion_field_path": pair["authorization"]["role_field_path"],
        "schema_version": "BSO_EQ_CODEX_NATIVE_SESSION_USER_EVENT_PROVENANCE_EVIDENCE_SCHEMA_V1",
        "transcript_prefix_sha256_through_invocation": pair["prefix_sha256"],
    }
    evidence["evidence_id"] = hash_without_field(evidence, "evidence_id")
    source_map = {
        "accepted_architecture_artifact_sha256": "frozen V4 architecture pin",
        "accepted_policy_schema_bundle_file_sha256": "frozen V4 bundle pin",
        "accepted_static_authority_manifest_sha256": "frozen V4 static-manifest pin",
        "materializer_or_review_contract_sha256": "frozen Phase-M R1 contract file hash",
        "schema_version": "frozen native-session evidence schema",
        "provenance_mode": "frozen human-origin provenance contract",
        "provenance_strength": "frozen native-session evidence schema",
        "native_session_store_root": "runtime native Codex session root discovery",
        "native_session_record_locator": "globally discovered native session file",
        "native_session_id": "native payload.session_id",
        "native_session_id_exact_value": "native payload.session_id",
        "native_session_id_source_field_path": "native source field name",
        "native_session_record_format": "native Codex session format",
        "native_source_file_sha256_at_capture": "native source snapshot bounded by supplied handoff mtime",
        "native_source_file_size_bytes_at_capture": "native source snapshot bounded by supplied handoff mtime",
        "matching_session_file_count": "global native session user-event pair search",
        "native_session_candidate_file_count": "global native session discovery bounded at capture",
        "native_session_parse_failure_file_count": "global native session parser results",
        "native_session_parse_failure_paths": "global native session parser results",
        "reattestation_event_ordinal": "native ordered UserMessage record",
        "reattestation_exact_match_count_in_session": "native exact-literal match enumeration",
        "reattestation_literal_utf8": "native UserMessage text bytes",
        "reattestation_literal_utf8_length_bytes": "native UserMessage text bytes",
        "reattestation_literal_utf8_sha256": "native UserMessage text bytes",
        "reattestation_native_record_sha256": "native UserMessage record bytes",
        "reattestation_user_role_assertion_exact_value": "native payload.item.type",
        "reattestation_user_role_assertion_field_path": "native payload.item.type field path",
        "invocation_event_ordinal": "native ordered UserMessage record",
        "invocation_exact_match_count_after_reattestation": "native exact-literal match enumeration",
        "invocation_literal_utf8": "native UserMessage text bytes",
        "invocation_literal_utf8_length_bytes": "native UserMessage text bytes",
        "invocation_literal_utf8_sha256": "native UserMessage text bytes",
        "invocation_native_record_sha256": "native UserMessage record bytes",
        "invocation_user_role_assertion_exact_value": "native payload.item.type",
        "invocation_user_role_assertion_field_path": "native payload.item.type field path",
        "transcript_prefix_sha256_through_invocation": "native source snapshot through invocation record",
        "evidence_id": "canonical JSON of reconstructed evidence fields excluding evidence_id",
    }
    if set(source_map) != set(evidence):
        raise ValueError("provenance field source map is incomplete")
    return evidence, source_map


def build_acceptance_bindings(evidence_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    architecture = {
        "acceptance_binding_id": "",
        "accepted_architecture_name": "RAW_LOCAL_CANDIDATE_COMPLETE_EQ_REVIEW_WITH_MULTI_RAW_SUBMISSION",
        "accepted_design_artifact_sha256": PINS["architecture"],
        "accepted_scope_constants": {
            "human_eq_normative_units": 4161, "preexisting_authenticated_hard_negatives": 58,
            "raw_count": 86, "structurally_eligible_candidate_relations": 4219,
        },
        "human_acceptance_decision_token": "ACCEPTED",
        "human_acceptance_provenance_evidence_id": evidence_id,
        "human_acceptance_provenance_id": evidence_id,
        "human_acceptance_provenance_mode": MODE,
        "schema_version": "BSO_EQ_WORKFLOW_ARCHITECTURE_ACCEPTANCE_BINDING_SCHEMA_V4",
    }
    policy = {
        "acceptance_binding_id": "", "accepted_bundle_file_sha256": PINS["bundle"],
        "accepted_static_authority_manifest_sha256": PINS["manifest"], "human_acceptance_decision_token": "ACCEPTED",
        "human_acceptance_provenance_evidence_id": evidence_id, "human_acceptance_provenance_id": evidence_id,
        "human_acceptance_provenance_mode": MODE,
        "schema_version": "BSO_EQ_POLICY_SCHEMA_BUNDLE_ACCEPTANCE_BINDING_SCHEMA_V4",
    }
    architecture["acceptance_binding_id"] = hash_without_field(architecture, "acceptance_binding_id")
    policy["acceptance_binding_id"] = hash_without_field(policy, "acceptance_binding_id")
    return architecture, policy


def _nested_dicts(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from _nested_dicts(child)
    elif isinstance(value, list):
        for child in value:
            yield from _nested_dicts(child)


def scan_structured_no_eq_runtime(root: Path, relation_ids: set[str]) -> dict[str, Any]:
    excluded_markers = (
        "schema", "prompt", "example", "diagnostic", "acceptance_binding", "current86_scope",
        "c2-r1", "c2r1", "bso-r", "bso_r", "materialization-prep", "provenance-interface",
        "remediation-r1-contract-package", "authority-freeze-current86-contract-package", "clean-phase-v",
    )
    examined: list[str] = []
    excluded: list[str] = []
    unparseable: list[dict[str, str]] = []
    matches: list[dict[str, str]] = []
    parseable_records = 0
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in {".json", ".jsonl"}:
            continue
        relative = path.relative_to(root).as_posix()
        lower = relative.lower()
        r1_r2 = re.search(r"(?:^|[^a-z0-9])r[12](?:[^a-z0-9]|$)", lower) is not None
        if r1_r2 or any(marker in lower for marker in excluded_markers):
            excluded.append(relative)
            continue
        examined.append(relative)
        try:
            if path.suffix.lower() == ".json":
                values = [load_json(path)]
            else:
                values = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            unparseable.append({"path": relative, "error_type": type(error).__name__})
            continue
        for value in values:
            parseable_records += 1
            for record in _nested_dicts(value):
                matches_record = (
                    record.get("schema_version") == QUALIFICATION_SCHEMA and QUALIFICATION_FIELDS.issubset(record)
                    and record.get("record_created_from_literal_human_submission") is True
                    and record.get("human_outcome") in QUALIFICATION_OUTCOMES
                    and record.get("relation_identity") in relation_ids
                )
                if matches_record:
                    record_id = record.get("record_id")
                    if not isinstance(record_id, str):
                        raise ValueError("runtime EQ record lacks a string record ID")
                    matches.append({"path": relative, "record_id": record_id, "relation_identity": record["relation_identity"]})
    record_ids = sorted(item["record_id"] for item in matches)
    if len(record_ids) != len(set(record_ids)):
        raise ValueError("duplicate runtime EQ record ID")
    return {
        "schema_version": "FA1B2DE_BSO_EQ_STRUCTURED_NO_EQ_RUNTIME_SCAN_R1",
        "scan_root": str(root), "files_examined": examined, "excluded_files": excluded,
        "excluded_file_count": len(excluded), "parseable_records": parseable_records,
        "unparseable_file_count": len(unparseable), "unparseable_files": unparseable,
        "matched_record_ids": record_ids, "matched_records": matches,
        "actual_runtime_record_count": len(matches),
        "status": "PASS" if not matches and not unparseable else "FAIL",
    }


def build_freeze_precondition(architecture_binding_id: str, scope_id: str, policy_binding_id: str, evidence_id: str) -> dict[str, Any]:
    result = {
        "architecture_acceptance_binding_id": architecture_binding_id,
        "current86_scope_id": scope_id,
        "human_origin_contract_hash": PINS["provenance_contract"],
        "human_origin_provenance_evidence_id": evidence_id,
        "human_origin_provenance_mode": MODE,
        "normative_source_evidence_profile_hash": PINS["normative_profile"],
        "policy_schema_bundle_acceptance_binding_id": policy_binding_id,
        "precondition_checks": precondition_checks({name: True for name in REQUIRED_PRECONDITION_CHECKS}),
        "schema_version": "BSO_EQ_AUTHORITY_FREEZE_PRECONDITION_VERIFICATION_SCHEMA_V4",
        "static_authority_manifest_sha256": PINS["manifest"],
        "verification_id": "",
    }
    result["verification_id"] = hash_without_field(result, "verification_id")
    return result


def build_freeze_envelope(architecture_binding_id: str, scope_id: str, policy_binding_id: str, verification_id: str) -> dict[str, Any]:
    result = {
        "architecture_acceptance_binding_id": architecture_binding_id,
        "canonicalization_spec_hash": PINS["canonicalization"],
        "current86_scope_id": scope_id,
        "freeze_precondition_verification_id": verification_id,
        "normative_source_evidence_profile_hash": PINS["normative_profile"],
        "policy_schema_bundle_acceptance_binding_id": policy_binding_id,
        "schema_version": "BSO_EQ_WORKFLOW_ARCHITECTURE_AUTHORITY_FREEZE_ENVELOPE_SCHEMA_V4",
        "static_authority_manifest_sha256": PINS["manifest"],
        "upstream_accepted_architecture_artifact_sha256": PINS["architecture"],
        "workflow_architecture_authority_hash": "",
    }
    result["workflow_architecture_authority_hash"] = hash_without_field(result, "workflow_architecture_authority_hash")
    return result


def create_archive(root: Path, archive: Path) -> None:
    """Create a reproducible file-only gzip tar without absorbing adjacent workspaces."""
    with tarfile.open(archive, "w:gz") as handle:
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            info = tarfile.TarInfo(f"{root.name}/{path.relative_to(root).as_posix()}")
            info.size = path.stat().st_size
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            info.mtime = 0
            with path.open("rb") as stream:
                handle.addfile(info, stream)


def _verify_phase_m_handoff(handoff: Path, expected_sha256: str, workspace_parent: Path) -> tuple[Path, dict[str, Any]]:
    actual = sha256_file(handoff)
    if actual != expected_sha256:
        raise ValueError("remediated Phase-M handoff outer SHA256 mismatch")
    fresh = Path(tempfile.mkdtemp(prefix="fa1b2de-clean-phase-v-phase-m-", dir=workspace_parent))
    try:
        extraction = extract_and_authenticate_archive(handoff, fresh / "handoff", expected_sha256)
        payload_root = Path(extraction["payload_root"])
        required = {
            "current86_scope_v4.json", "fresh_upstream_extraction_authentication.json",
            "human_v4_remediation_acceptance_provenance_evidence.json",
            "human_v4_remediation_acceptance_provenance_independent_recompute.json",
            "materialization_hard_gate_table_v4_r1.json", "materialization_summary_v4_r1.json",
            "policy_schema_bundle_acceptance_binding_v4.json", "structured_no_eq_runtime_scan.json",
            "workflow_architecture_acceptance_binding_v4.json",
        }
        missing = sorted(name for name in required if not (payload_root / name).is_file())
        if missing:
            raise ValueError(f"remediated Phase-M handoff lacks required evidence: {missing}")
        if verify_inventory(payload_root)["file_list_exactness"] is False or verify_inventory(payload_root)["sha256sums_exactness"] is False:
            raise ValueError("remediated Phase-M handoff inventory verification failed")
        copied = Path(tempfile.mkdtemp(prefix="fa1b2de-clean-phase-v-phase-m-retained-", dir=workspace_parent))
        shutil.copytree(payload_root, copied / payload_root.name)
        retained = copied / payload_root.name
        extraction.update({"outer_sha256": actual, "outer_sha256_match": True, "status": "PASS"})
        return retained, extraction
    finally:
        shutil.rmtree(fresh)


def compare_exact(name: str, independently_reconstructed: Any, phase_m_object: Any) -> dict[str, Any]:
    if isinstance(independently_reconstructed, dict) and isinstance(phase_m_object, dict):
        fields = sorted(set(independently_reconstructed) | set(phase_m_object))
        equality = {field: independently_reconstructed.get(field) == phase_m_object.get(field) for field in fields}
        equal = all(equality.values())
    else:
        equality, equal = {}, independently_reconstructed == phase_m_object
    if not equal:
        raise ValueError(f"independent {name} reconstruction differs from Phase-M comparison evidence")
    return {"comparison_target": name, "exact_equal": True, "field_equality": equality, "status": "PASS"}


def audit_final_archive(
    archive: Path,
    handoff: Path,
    expected_handoff_sha256: str,
    artifact_root: Path,
    workspace_parent: Path,
) -> dict[str, Any]:
    audit_root = Path(tempfile.mkdtemp(prefix="fa1b2de-clean-phase-v-final-audit-", dir=workspace_parent))
    try:
        with tarfile.open(archive, "r:gz") as handle:
            for member in handle.getmembers():
                target = _safe_member_path(audit_root, member.name)
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isreg():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    source = handle.extractfile(member)
                    if source is None:
                        raise ValueError("final archive member cannot be read")
                    with target.open("wb") as output:
                        shutil.copyfileobj(source, output)
                else:
                    raise ValueError("final archive contains unsupported member")
        roots = [path.parent for path in audit_root.rglob("FILE_LIST.txt")]
        if len(roots) != 1:
            raise ValueError("final archive must have exactly one output inventory root")
        root = roots[0]
        inventory = verify_inventory(root)
        if not inventory["file_list_exactness"] or not inventory["sha256sums_exactness"]:
            raise ValueError("final archive FILE_LIST or SHA256SUMS is not exact")
        precondition = load_json(root / "authority_freeze_precondition_verification_v4.json")
        envelope = load_json(root / "workflow_architecture_authority_freeze_envelope_v4.json")
        scope = load_json(root / "independent_current86_scope_recomputation_r1.json")["reconstructed_scope"]
        provenance = load_json(root / "independent_human_provenance_from_source_reconstruction.json")["provenance_evidence"]
        summary = load_json(root / "final_freeze_summary_v4_r1.json")
        if precondition.get("verification_id") != hash_without_field(precondition, "verification_id"):
            raise ValueError("final archive precondition verification ID does not recompute")
        if envelope.get("workflow_architecture_authority_hash") != hash_without_field(envelope, "workflow_architecture_authority_hash"):
            raise ValueError("final archive authority hash does not recompute")
        if scope.get("scope_id") != hash_without_field(scope, "scope_id"):
            raise ValueError("final archive current86 scope ID does not recompute")
        auth_path = Path.cwd() / "04_human_messages" / "Human_Authorization_FA1B2de_BSO_EQ_V4_Phase_M_Remediation_R1.txt"
        invocation_path = Path.cwd() / "04_human_messages" / "Human_Invocation_FA1B2de_BSO_EQ_V4_Phase_M_Remediation_R1.txt"
        pair = discover_native_provenance(handoff, auth_path.read_bytes(), invocation_path.read_bytes())
        rederived, _ = build_provenance_evidence(pair, auth_path.read_bytes(), invocation_path.read_bytes())
        if provenance != rederived:
            raise ValueError("final archive native provenance reconstruction differs from original native source")
        runtime = scan_structured_no_eq_runtime(artifact_root, {item["relation_identity"] for item in scope["relation_membership"]})
        if runtime["status"] != "PASS" or runtime["actual_runtime_record_count"] != 0:
            raise ValueError("final archive runtime no-EQ recheck failed")
        required_summary = {
            "authority_freeze_status": "FROZEN_INDEPENDENTLY_VERIFIED",
            "eq_execution_authorized": "NO",
            "human_candidate_qualification_authorized": "NO",
            "positive_support_creation_authorized": "NO",
            "bso_a_adjudication_authorized": "NO",
            "workflow_architecture_authority_hash": envelope["workflow_architecture_authority_hash"],
        }
        if any(summary.get(key) != value for key, value in required_summary.items()):
            raise ValueError("final archive summary has contradictory authority fields")
        if summary.get("superseded_phase_m_handoff_sha256") == "33af0f027225732fbef7d1011859b475e73f4986e383057f5f9d44971e01208f":
            raise ValueError("final archive summary imports a superseded Phase-M handoff")
        return {
            "schema_version": "FA1B2DE_BSO_EQ_V4_FINAL_TAR_POST_PACKAGE_AUDIT_R1",
            "status": "PASS", "final_archive_path": str(archive), "final_archive_sha256": sha256_file(archive),
            "second_fresh_audit_directory": str(audit_root), "inventory": inventory,
            "precondition_verification_id": precondition["verification_id"],
            "workflow_architecture_authority_hash": envelope["workflow_architecture_authority_hash"],
            "native_prefix_sha256": pair["prefix_sha256"],
            "actual_current86_eq_runtime_record_count": runtime["actual_runtime_record_count"],
            "superseded_phase_v_derivation_source": "NONE",
        }
    finally:
        shutil.rmtree(audit_root)


def run_verifier(handoff: Path, expected_sha256: str, package_root: Path, output_parent: Path) -> tuple[Path, Path, dict[str, Any]]:
    timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = output_parent / f"fa1b2de-bso-eq-v4-clean-phase-v-verifier-r1-{timestamp}"
    if output.exists():
        raise ValueError("fresh verifier output directory already exists")
    output.mkdir(parents=True)
    retained_phase_m: Path | None = None
    try:
        retained_phase_m, handoff_auth = _verify_phase_m_handoff(handoff, expected_sha256, output_parent)
        phase_m_evidence = load_json(retained_phase_m / "human_v4_remediation_acceptance_provenance_evidence.json")
        phase_m_architecture_binding = load_json(retained_phase_m / "workflow_architecture_acceptance_binding_v4.json")
        phase_m_policy_binding = load_json(retained_phase_m / "policy_schema_bundle_acceptance_binding_v4.json")
        phase_m_scope = load_json(retained_phase_m / "current86_scope_v4.json")

        static = authenticate_v4_static(package_root)
        r2 = authenticate_r2_evidence(package_root)
        authorization = (package_root / "04_human_messages" / "Human_Authorization_FA1B2de_BSO_EQ_V4_Phase_M_Remediation_R1.txt").read_bytes()
        invocation = (package_root / "04_human_messages" / "Human_Invocation_FA1B2de_BSO_EQ_V4_Phase_M_Remediation_R1.txt").read_bytes()
        semantics = acceptance_semantics(authorization, invocation, package_root)
        native_pair = discover_native_provenance(handoff, authorization, invocation)
        provenance, source_map = build_provenance_evidence(native_pair, authorization, invocation)
        provenance_comparison = compare_exact("human provenance evidence", provenance, phase_m_evidence)
        provenance_comparison.update({
            "phase_m_object_role": "COMPARISON_EVIDENCE_ONLY_NOT_A_DERIVATION_SOURCE",
            "evidence_id_recomputed": provenance["evidence_id"],
        })
        architecture_binding, policy_binding = build_acceptance_bindings(provenance["evidence_id"])
        architecture_comparison = compare_exact("workflow architecture acceptance binding", architecture_binding, phase_m_architecture_binding)
        policy_comparison = compare_exact("policy schema acceptance binding", policy_binding, phase_m_policy_binding)
        scope, upstream = rematerialize_upstream_scope(Path("/home/cph/experiment-artifacts"), output_parent)
        scope_comparison = compare_exact("current86 scope", scope, phase_m_scope)
        scope_comparison.update({
            "reconstructed_scope_id": scope["scope_id"], "phase_m_scope_id": phase_m_scope["scope_id"],
            "relation_set_exact_equality": True, "raw_key_set_exact_equality": True,
        })
        frozen_a = recompute_frozen_a_batch(Path("/home/cph/experiment-artifacts"))
        runtime = scan_structured_no_eq_runtime(Path("/home/cph/experiment-artifacts"), {item["relation_identity"] for item in scope["relation_membership"]})
        if runtime["status"] != "PASS" or runtime["actual_runtime_record_count"] != 0:
            raise ValueError("structured full-root no-EQ runtime scan failed")

        prior_gates = {
            "PHASE_M_REMEDIATED_HANDOFF_INTEGRITY": handoff_auth["status"] == "PASS",
            "FILE_LIST_EXACTNESS_HARD_GATE": handoff_auth["file_list_exactness"] == "PASS",
            "SHA256SUMS_HARD_GATE": handoff_auth["sha256sums_exactness"] == "PASS",
            "V4_STATIC_RECOMPUTATION": static["status"] == "PASS",
            "R2_APPLICABILITY": r2["status"] == "PASS",
            "HUMAN_PROVENANCE_FROM_SOURCE_RECONSTRUCTION": provenance_comparison["status"] == "PASS",
            "GLOBAL_NATIVE_SESSION_UNIQUENESS": native_pair["matching_session_file_count"] == 1,
            "ACCEPTANCE_SEMANTICS_ALL_EXPLICIT": semantics["acceptance_semantics_all_explicit"],
            "ACCEPTANCE_BINDINGS_INDEPENDENT_RECOMPUTATION": architecture_comparison["status"] == "PASS" and policy_comparison["status"] == "PASS",
            "CURRENT86_SCOPE_INDEPENDENT_RECOMPUTATION": upstream["primary_independent_relation_set_equality"] == "PASS",
            "CURRENT86_SCOPE_EXACT_SET_EQUALITY": scope_comparison["status"] == "PASS",
            "FROZEN_A_BATCH_UNCHANGED": frozen_a["status"] == "PASS",
            "STRUCTURED_NO_EQ_RUNTIME_SCAN": runtime["status"] == "PASS" and runtime["actual_runtime_record_count"] == 0,
        }
        if not all(prior_gates.values()):
            raise ValueError("one or more V4 hard gates failed before precondition materialization")
        precondition = build_freeze_precondition(
            architecture_binding["acceptance_binding_id"], scope["scope_id"], policy_binding["acceptance_binding_id"], provenance["evidence_id"]
        )
        envelope = build_freeze_envelope(
            architecture_binding["acceptance_binding_id"], scope["scope_id"], policy_binding["acceptance_binding_id"], precondition["verification_id"]
        )
        freeze_verification = {
            "schema_version": "FA1B2DE_BSO_EQ_V4_INDEPENDENT_FREEZE_VERIFICATION_R1",
            "status": "PASS", "precondition_verification_id": precondition["verification_id"],
            "precondition_id_recomputed": precondition["verification_id"] == hash_without_field(precondition, "verification_id"),
            "workflow_architecture_authority_hash": envelope["workflow_architecture_authority_hash"],
            "authority_hash_recomputed": envelope["workflow_architecture_authority_hash"] == hash_without_field(envelope, "workflow_architecture_authority_hash"),
            "superseded_phase_v_derivation_source": "NONE",
        }
        evidence_files: dict[str, Any] = {
            "independent_phase_m_handoff_authentication_r1.json": handoff_auth,
            "independent_v4_static_recomputation_r1.json": {"static": static, "r2_applicability": r2},
            "independent_human_provenance_from_source_reconstruction.json": {
                "schema_version": "FA1B2DE_BSO_EQ_V4_HUMAN_PROVENANCE_SOURCE_RECONSTRUCTION_R1",
                "status": "PASS", "native_pair": {key: value for key, value in native_pair.items() if key not in {"authorization", "invocation"}},
                "provenance_evidence": provenance, "field_source_map": source_map,
            },
            "independent_human_provenance_comparison_r1.json": provenance_comparison,
            "independent_acceptance_semantics_r1.json": semantics,
            "independent_acceptance_binding_recomputation_r1.json": {
                "schema_version": "FA1B2DE_BSO_EQ_V4_ACCEPTANCE_BINDING_RECOMPUTATION_R1", "status": "PASS",
                "architecture_binding": architecture_binding, "policy_schema_bundle_binding": policy_binding,
                "architecture_phase_m_exact_comparison": architecture_comparison, "policy_phase_m_exact_comparison": policy_comparison,
            },
            "independent_upstream_extraction_authentication_r1.json": upstream,
            "independent_current86_scope_recomputation_r1.json": {
                "schema_version": "FA1B2DE_BSO_EQ_V4_CURRENT86_SCOPE_RECOMPUTATION_R1", "status": "PASS",
                "reconstructed_scope": scope, "phase_m_comparison": scope_comparison,
            },
            "independent_frozen_a_batch_recomputation_r1.json": frozen_a,
            "independent_structured_no_eq_runtime_scan_r1.json": runtime,
            "authority_freeze_precondition_verification_v4.json": precondition,
            "workflow_architecture_authority_freeze_envelope_v4.json": envelope,
            "independent_freeze_verification_v4_r1.json": freeze_verification,
            "final_freeze_summary_v4_r1.json": {
                "schema_version": "FA1B2DE_BSO_EQ_V4_FINAL_FREEZE_SUMMARY_R1",
                "authority_freeze_status": "FROZEN_INDEPENDENTLY_VERIFIED",
                "workflow_architecture_authority_hash": envelope["workflow_architecture_authority_hash"],
                "freeze_precondition_verification_id": precondition["verification_id"],
                "eq_execution_authorized": "NO", "human_candidate_qualification_authorized": "NO",
                "positive_support_creation_authorized": "NO", "bso_a_adjudication_authorized": "NO",
                "current86_raw_count": 86, "current86_relation_count": 4219,
                "actual_current86_eq_runtime_record_count": 0,
                "superseded_phase_m_handoff_sha256": None, "superseded_phase_v_derivation_source": "NONE",
                "next_authorized_action": "DESIGN_BSO_EQ_EXECUTION_CONTRACT_ONLY",
            },
        }
        for name, value in evidence_files.items():
            write_json(output / name, value)
        shutil.copyfile(Path(__file__), output / "clean_phase_v_v4_verifier_r1.py")
        write_inventory(output)
        if not (verification := verify_inventory(output))["file_list_exactness"] or not verification["sha256sums_exactness"]:
            raise ValueError("verifier output inventory did not self-verify")
        archive = output_parent / f"{output.name}.tar.gz"
        create_archive(output, archive)
        audit = audit_final_archive(archive, handoff, expected_sha256, Path("/home/cph/experiment-artifacts"), output_parent)
        write_json(output_parent / f"{output.name}.post_package_audit_r1.json", audit)
        return output, archive, audit
    finally:
        if retained_phase_m is not None:
            shutil.rmtree(retained_phase_m.parent)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--handoff", required=True, type=Path)
    parser.add_argument("--expected-handoff-sha256", required=True)
    parser.add_argument("--package-root", type=Path, default=Path.cwd())
    parser.add_argument("--output-parent", type=Path, default=None)
    arguments = parser.parse_args()
    package_root = arguments.package_root.resolve()
    output_parent = (arguments.output_parent or package_root.parent).resolve()
    try:
        output, archive, audit = run_verifier(
            arguments.handoff.resolve(), arguments.expected_handoff_sha256, package_root, output_parent
        )
    except Exception as error:
        print("WORKFLOW_ARCHITECTURE_AUTHORITY_HASH=NOT_FROZEN")
        print("AUTHORITY_FREEZE_STATUS=NOT_FROZEN")
        print("EQ_EXECUTION_AUTHORIZED=NO")
        print(f"CLEAN_PHASE_V_V4_VERIFIER_R1_ERROR={type(error).__name__}:{error}")
        raise SystemExit(1)
    print("AUTHORITY_FREEZE_PHASE_VERDICT=PASS_BSO_EQ_V4_WORKFLOW_AUTHORITY_FROZEN_INDEPENDENTLY_VERIFIED_CLEAN_R1")
    print("PHASE_M_REMEDIATED_HANDOFF_INTEGRITY=PASS")
    print("FILE_LIST_EXACTNESS_HARD_GATE=PASS")
    print("SHA256SUMS_HARD_GATE=PASS")
    print("V4_STATIC_RECOMPUTATION=PASS")
    print("R2_APPLICABILITY=PASS")
    print("HUMAN_PROVENANCE_FROM_SOURCE_RECONSTRUCTION=PASS")
    print("GLOBAL_NATIVE_SESSION_UNIQUENESS=PASS")
    print("ACCEPTANCE_SEMANTICS_ALL_EXPLICIT=PASS")
    print("ACCEPTANCE_BINDINGS_INDEPENDENT_RECOMPUTATION=PASS")
    print("CURRENT86_SCOPE_INDEPENDENT_RECOMPUTATION=PASS")
    print("CURRENT86_SCOPE_EXACT_SET_EQUALITY=PASS")
    print("CURRENT86_RAW_COUNT=86")
    print("CURRENT86_RELATION_COUNT=4219")
    print("PREEXISTING_HARD_NEGATIVE_COUNT=58")
    print("HUMAN_EQ_REVIEW_REQUIRED_COUNT=4161")
    print("FROZEN_A_BATCH_UNCHANGED=PASS")
    print("STRUCTURED_NO_EQ_RUNTIME_SCAN=PASS")
    print("ACTUAL_CURRENT86_EQ_RUNTIME_RECORD_COUNT=0")
    print(f"FREEZE_PRECONDITION_VERIFICATION_ID={audit['precondition_verification_id']}")
    print(f"WORKFLOW_ARCHITECTURE_AUTHORITY_HASH={audit['workflow_architecture_authority_hash']}")
    print("AUTHORITY_FREEZE_STATUS=FROZEN_INDEPENDENTLY_VERIFIED")
    print("EQ_EXECUTION_AUTHORIZED=NO")
    print("HUMAN_CANDIDATE_QUALIFICATION_AUTHORIZED=NO")
    print("POSITIVE_SUPPORT_CREATION_AUTHORIZED=NO")
    print("BSO_A_ADJUDICATION_AUTHORIZED=NO")
    print(f"FINAL_FREEZE_HANDOFF={archive}")
    print(f"FINAL_FREEZE_HANDOFF_SHA256={audit['final_archive_sha256']}")
    print("NEXT_AUTHORIZED_ACTION=DESIGN_BSO_EQ_EXECUTION_CONTRACT_ONLY")
    print("STOP_AFTER_CLEAN_PHASE_V_V4_FREEZE_R1")


if __name__ == "__main__":
    main()
